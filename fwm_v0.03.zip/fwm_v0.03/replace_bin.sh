#!/bin/bash
#brief:
#version: 0.01
#date   : 7/29/2019

imagefile=$1
fwm="./core/fwm"
rp="core/replace/src"
if [ ! -f $fwm ]; then
	echo "Please put this script file to fwm folder."
	exit 1
fi

if [ $# != 1 ]; then
        echo "usage: ./fwm_extract_www.sh <input file>"
	exit 1
fi

if [ ! -e $imagefile ]; then
	echo "<$imagefile> doesn't exist."
	exit 1
fi

if [ ! -f $imagefile ]; then
	echo "<$imagefile> is NOT a file."
	exit 1
fi

function replace_files()
{
    if [ ! -e "replace_files" ]; then
            echo "there was no replace folder in there."
            return
    fi

    echo "INFO: It replace the old file with new one."

    ls replace_files > replace_list.txt

    while read replaced_file;
    do
        searched_file=`find "$rp"/root/bin/ "$rp"/root/sbin/ "$rp"/root/lib/ "$rp"/root/usr/ -name $replaced_file`
        if [ "$?" == "1" ];then
            continue;
        fi 
        #cp  "replace_files/$replaced_file" $searched_file
        cp  "replace_files/$replaced_file" "$rp"/root/usr/
        echo -e "#$searched_file"
    done < replace_list.txt

    unlink replace_list.txt
}

function chkEnv()
{
    if [ -d ./processing ]; then
	rm ./processing/* -f
    else
	mkdir processing
    fi
    if [ -d ./output ]; then
	rm ./output/* -f
    else
	mkdir output
    fi
}

echo "INFO: Extrack FW image and Prepare root file system."
mkdir -p root $rp/root                                             || exit 1
chkEnv                                                             || exit 1
$fwm -i $imagefile -s                                              || exit 1
if [ -e processing/root.ori.bin ];then
    mounted_path="processing/root.ori.bin"
else
    mounted_path="processing/root.bin"
fi
printf "===>$mounted_path\n"
sync
mount -o loop $mounted_path ./root                                 || exit 1
cp -r root $rp
replace_files                                                      || exit 1

chkEnv                                                             || exit 1
$fwm -i $imagefile -r -o ./output.ima                              || exit 1
sync
umount ./root && sleep 2                                           || exit 1
rm -rf ./root                                                      || exit 1
rm -rf $rp/root                                                    || exit 1
rm -rf processing                                                  || exit 1
exit 0
